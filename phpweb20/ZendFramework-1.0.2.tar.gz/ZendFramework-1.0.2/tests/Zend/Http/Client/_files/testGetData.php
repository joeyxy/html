<?php
	echo serialize($_GET);
?>