<?php
	echo serialize($_POST);
?>