<?php
echo serialize($_GET) . "\n" . serialize($_POST);