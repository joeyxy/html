<?php
echo serialize($_COOKIE);