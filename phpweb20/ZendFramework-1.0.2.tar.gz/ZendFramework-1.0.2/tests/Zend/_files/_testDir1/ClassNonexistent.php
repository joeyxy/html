<?php
require_once 'PHPUnit/Util/Filter.php';

PHPUnit_Util_Filter::addFileToFilter(__FILE__);

/**
 * Empty file that is used in unit testing by ZendTest::testLoadClassNonexistent()
 *
 * @package Zend
 * @subpackage UnitTests
 */
